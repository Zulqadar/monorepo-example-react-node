const add = (a, b) => a + b;
module.exports = { add };